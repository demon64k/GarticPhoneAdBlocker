const TRACKING_DOMAINS = [
  'microsoft.com',
  'insight',
  'azure.com',
  'googlesyndication.com',
  'doubleclick.net',
  'googleadservices.com',
  'google-analytics.com',
  'googletagmanager.com',
  'pagead',
  'adservice.google',
  'adnxs.com',
  'taboola.com',
  'outbrain.com',
  'amazon-adsystem.com',
  'facebook.com/tr',
  'scorecardresearch.com',
  'quantserve.com',
  'popads.net',
  'propellerads.com'
];

chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    const url = details.url.toLowerCase();
    if (TRACKING_DOMAINS.some(domain => url.includes(domain))) {
      console.log('Gartic AdBlocker: заблокировано', details.url);
      return { cancel: true };
    }
    return {};
  },
  {
    urls: ['<all_urls>'],
    types: ['script', 'image', 'xmlhttprequest', 'sub_frame', 'main_frame']
  },
  ['blocking']
);

console.log('GarticPhone AdBlocker для Firefox установлен');