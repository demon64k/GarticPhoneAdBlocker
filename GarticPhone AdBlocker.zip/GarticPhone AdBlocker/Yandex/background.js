chrome.runtime.onInstalled.addListener(() => {
  console.log('GarticPhone AdBlocker для Яндекс Браузера установлен');
});

chrome.runtime.onStartup.addListener(() => {
  console.log('GarticPhone AdBlocker запущен');
});