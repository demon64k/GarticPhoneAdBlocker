chrome.runtime.onInstalled.addListener(() => {
  console.log('GarticPhone AdBlocker установлен');
});

chrome.runtime.onStartup.addListener(() => {
  console.log('GarticPhone AdBlocker запущен');
});