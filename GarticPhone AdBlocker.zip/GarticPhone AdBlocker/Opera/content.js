(function () {
  'use strict';

  const BLOCKED_DOMAINS = [
    'adinplay.com',
    'adnxs.com',
    'googlesyndication.com',
    'doubleclick.net',
    'googleadservices.com',
    'google-analytics.com',
    'googletagmanager.com',
    'taboola.com',
    'outbrain.com',
    'amazon-adsystem.com',
    'facebook.com/tr',
    'scorecardresearch.com',
    'quantserve.com',
    'popads.net',
    'propellerads.com',
    'revcontent.com',
    'mgid.com',
    'chitika.com',
    'buysellads.com',
    'muslimhands.org',
    'insight.azureedge.net',
    'azureedge.net',
    'rubiconproject.com',
    'pubmatic.com',
    'criteo.com',
    'indexww.com',
    'lijit.com',
    'spotxchange.com',
    'advertising.com',
    'ads.yahoo.com',
    'gemini.yahoo.com',
    'liadm.com',
    'inmobi.com',
    '3lift.com',
    'onetag-sys.com',
    'bids.ws',
    'id5-sync.com',
    'rlcdn.com',
    'bluekai.com',
    'demdex.net',
    'krxd.net',
    'openx.net',
    'smartadserver.com',
    'yieldmo.com',
    'sharethrough.com',
    'smaato.net',
    'appnexus.com',
    'contextweb.com',
    'districtm.io',
    'emxdigital.com',
    'gumgum.com',
    'imedia.cz',
    'liveramp.com',
    'media.net',
    'oneadvertising.com',
    'sovrn.com',
    'stickyadstv.com',
    'teads.tv',
    'triplelift.com',
    'undertone.com',
    'verizonmedia.com',
    'yieldlift.com',
    'tiktok.com',
    'analytics.tiktok.com'
  ];

  function isAdElement(element) {
    if (!element || !element.tagName) return false;

    const tagName = element.tagName.toLowerCase();

    if (tagName === 'iframe' || tagName === 'img' || tagName === 'script') {
      const src = (element.getAttribute('src') || '').toLowerCase();
      if (BLOCKED_DOMAINS.some(domain => src.includes(domain))) return true;

      if (tagName === 'iframe') {
        const width = parseInt(element.getAttribute('width') || '0');
        const height = parseInt(element.getAttribute('height') || '0');
        if ((width === 160 && height === 600) || 
            (width === 300 && height === 600) ||
            (width === 728 && height === 90) ||
            (width === 300 && height === 250)) {
          return true;
        }
      }
    }

    const id = (element.id || '').toLowerCase();
    const className = (element.className && typeof element.className === 'string') ? element.className.toLowerCase() : '';
    
    if (id.startsWith('div-gpt-ad') || id.startsWith('google_ads_iframe')) return true;
    if (className.includes('adsbygoogle')) return true;
    if (element.hasAttribute('data-ad-client') || element.hasAttribute('data-ad-slot')) return true;
    if (id.includes('adinplay') || className.includes('adinplay')) return true;
    if (id.includes('muslimhands') || className.includes('muslimhands')) return true;

    return false;
  }

  function removeAdElement(element) {
    if (!element || !element.parentNode) return;
    try {
      element.style.setProperty('display', 'none', 'important');
      element.style.setProperty('visibility', 'hidden', 'important');
      element.style.setProperty('opacity', '0', 'important');
      element.style.setProperty('pointer-events', 'none', 'important');
      element.style.setProperty('width', '0', 'important');
      element.style.setProperty('height', '0', 'important');
      element.style.setProperty('position', 'absolute', 'important');
      element.style.setProperty('left', '-9999px', 'important');
      element.style.setProperty('top', '-9999px', 'important');
      element.style.setProperty('z-index', '-9999', 'important');

      setTimeout(() => {
        if (element && element.parentNode) {
          try {
            element.parentNode.removeChild(element);
          } catch (e) {}
        }
      }, 100);
    } catch (e) {}
  }

  function cleanupAds(root) {
    if (!root) return;

    if (root.nodeType === Node.ELEMENT_NODE) {
      if (isAdElement(root)) {
        removeAdElement(root);
        return;
      }
    }

    if (root.querySelectorAll) {
      const iframes = root.querySelectorAll('iframe');
      const imgs = root.querySelectorAll('img');
      const scripts = root.querySelectorAll('script[src]');
      const divs = root.querySelectorAll('div[id^="div-gpt-ad"], div[id^="google_ads_iframe"], ins.adsbygoogle, [data-ad-client], [data-ad-slot], [id*="adinplay"], [class*="adinplay"], [id*="muslimhands"], [class*="muslimhands"]');
      
      iframes.forEach(el => { if (isAdElement(el)) removeAdElement(el); });
      imgs.forEach(el => { if (isAdElement(el)) removeAdElement(el); });
      scripts.forEach(el => { if (isAdElement(el)) removeAdElement(el); });
      divs.forEach(el => removeAdElement(el));
    }
  }

  function initialCleanup() {
    try {
      cleanupAds(document);
    } catch (e) {
      console.error('Gartic AdBlocker Opera error:', e);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialCleanup);
  } else {
    initialCleanup();
  }

  const observer = new MutationObserver((mutations) => {
    try {
      for (const mutation of mutations) {
        if (mutation.addedNodes && mutation.addedNodes.length > 0) {
          for (const node of mutation.addedNodes) {
            if (node.nodeType === Node.ELEMENT_NODE) {
              cleanupAds(node);
            }
          }
        }
      }
    } catch (e) {
      console.error('Gartic AdBlocker Opera observer error:', e);
    }
  });

  observer.observe(document.documentElement || document.body, {
    childList: true,
    subtree: true
  });

  setInterval(() => {
    try {
      cleanupAds(document);
    } catch (e) {
      console.error('Gartic AdBlocker Opera interval error:', e);
    }
  }, 2000);

  window.addEventListener('load', () => {
    setTimeout(initialCleanup, 500);
    setTimeout(initialCleanup, 1500);
    setTimeout(initialCleanup, 3000);
  });

  console.log('Gartic AdBlocker Opera: активен на', window.location.hostname);
})();