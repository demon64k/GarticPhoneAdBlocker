const BLOCKED_DOMAINS = [
  'adinplay.com',
  'adnxs.com',
  'googlesyndication.com',
  'doubleclick.net',
  'googleadservices.com',
  'google-analytics.com',
  'googletagmanager.com',
  'pagead2.googlesyndication.com',
  'adservice.google.com',
  'taboola.com',
  'outbrain.com',
  'amazon-adsystem.com',
  'facebook.com/tr',
  'scorecardresearch.com',
  'quantserve.com',
  'popads.net',
  'propellerads.com',
  'revcontent.com',
  'mgid.com',
  'chitika.com',
  'buysellads.com',
  'muslimhands.org',
  'insight.azureedge.net',
  'azureedge.net',
  'rubiconproject.com',
  'pubmatic.com',
  'criteo.com',
  'indexww.com',
  'lijit.com',
  'spotxchange.com',
  'advertising.com',
  'ads.yahoo.com',
  'gemini.yahoo.com',
  'liadm.com',
  'inmobi.com',
  '3lift.com',
  'onetag-sys.com',
  'bids.ws',
  'id5-sync.com',
  'rlcdn.com',
  'bluekai.com',
  'demdex.net',
  'krxd.net',
  'openx.net',
  'smartadserver.com',
  'yieldmo.com',
  'sharethrough.com',
  'smaato.net',
  'appnexus.com',
  'contextweb.com',
  'districtm.io',
  'emxdigital.com',
  'gumgum.com',
  'imedia.cz',
  'liveramp.com',
  'media.net',
  'oneadvertising.com',
  'sovrn.com',
  'stickyadstv.com',
  'teads.tv',
  'triplelift.com',
  'undertone.com',
  'verizonmedia.com',
  'yieldlift.com',
  'tiktok.com',
  'analytics.tiktok.com',
  'api.adinplay.com',
  'ads.adinplay.com',
  'cdn.adinplay.com'
];

chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    const url = details.url.toLowerCase();
    if (BLOCKED_DOMAINS.some(domain => url.includes(domain))) {
      console.log('Gartic AdBlocker Opera: заблокировано', details.url);
      return { cancel: true };
    }
    return {};
  },
  {
    urls: ['<all_urls>'],
    types: ['script', 'image', 'xmlhttprequest', 'sub_frame', 'stylesheet', 'font', 'object', 'media', 'main_frame']
  },
  ['blocking']
);

console.log('GarticPhone AdBlocker для Opera установлен');